//package com.sparta.memoproject.image;
//
//import com.amazonaws.services.s3.AmazonS3;
//import com.amazonaws.services.s3.model.DeleteObjectRequest;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Primary;
//import org.springframework.stereotype.Service;
//
//@Service
//public class AmazonService {
//
//    @Value("${cloud.aws.s3.bucket}")
//    public String bucket;  // S3 버킷 이름
//    private final AmazonS3 amazonS3;
//
//    public AmazonService(AmazonS3 amazonS3) {
//        this.amazonS3 = amazonS3;
//    }
//
//    @Primary
//    public void remove(String filename) {
//        amazonS3.deleteObject(new DeleteObjectRequest(bucket,filename));
//    }
//}
