package com.sparta.memoproject.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class imageDto {

    private String imageName;
}
