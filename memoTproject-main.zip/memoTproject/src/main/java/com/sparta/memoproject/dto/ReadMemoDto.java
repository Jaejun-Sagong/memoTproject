package com.sparta.memoproject.dto;

import com.sparta.memoproject.model.Memo;

import java.util.List;

public class ReadMemoDto {
    List<Memo> memoList;
    Long cntHeart;
}

